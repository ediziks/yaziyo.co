tinymce.addI18n('pl',# Generated pot
# Translators:
# mm, 2013-2014
# Stefan Wajda <zwiastun@zwiastun.net>, 2015-2016
msgid ""
msgstr ""
"Project-Id-Version: TinyMCE\n"
"Report-Msgid-Bugs-To: http://moxiecode.com\n"
"POT-Creation-Date: 2013-03-21 16:18:52+00:00\n"
"PO-Revision-Date: 2016-09-14 12:02+0000\n"
"Last-Translator: Stefan Wajda <zwiastun@zwiastun.net>\n"
"Language-Team: Polish (http://www.transifex.com/moxiecode/tinymce/language/pl/)\n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=UTF-8\n"
"Content-Transfer-Encoding: 8bit\n"
"\"#: i18n:\n"
"Language: pl\n"
"Plural-Forms: nplurals=3; plural=(n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);\n"

msgid "Insert link"
msgstr "Wstaw łącze"

msgid "Insert/edit link"
msgstr "Wstaw/edytuj łącze"

msgid "Text to display"
msgstr "Tekst do wyświetlenia"

msgid "Url"
msgstr "Url"

msgid "Target"
msgstr "Cel"

msgid "None"
msgstr "Brak"

msgid "New window"
msgstr "Nowe okno"

msgid "Remove link"
msgstr "Usuń łącze"

msgid "Anchors"
msgstr "Kotwice"

msgid ""
"The URL you entered seems to be an email address. Do you want to add the "
"required mailto: prefix?"
msgstr "URL, który wprowadziłeś wygląda na adres e-mail. Czy chcesz dodać mailto: jako prefiks?"

msgid ""
"The URL you entered seems to be an external link. Do you want to add the "
"required http:// prefix?"
msgstr "URL, który wprowadziłeś wygląda na link zewnętrzny. Czy chcesz dodać http:// jako prefiks?"
);