# Client OIDC library

Taken from https://github.com/IdentityModel/oidc-client-js (1.9.1)
