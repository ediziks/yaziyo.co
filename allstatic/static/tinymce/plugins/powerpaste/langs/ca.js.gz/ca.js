tinymce.addI18n('ca', {
"Paste Formatting Options": "Opcions per enganxar el format",
"Choose to keep or remove formatting in the pasted content.": "Trieu si voleu conservar o eliminar el format al contingut enganxat",
"Keep Formatting": "Conserva el format",
"Remove Formatting": "Elimina el format",
"Local Image Import": "Importaci\u00F3 d\'imatges locals",
"Trigger paste again from the keyboard to paste content with images.": "Activeu l\'eina torna a enganxar del teclat per enganxar contingut amb imatges.",
"Adobe Flash is required to import images from Microsoft Office. Install the <a href=\"http://get.adobe.com/flashplayer/\" target=\"_blank\">Adobe Flash Player</a>.": "\u00C9s necessari l\'Adobe Flash per importar imatges de Microsoft Office. Instal\u00B7la l\'<a href=\"http://get.adobe.com/flashplayer/\" target=\"_blank\">Adobe Flash Player</a>.",
"Press <span class=\"ephox-polish-help-kbd\">ESC</span> to ignore local images and continue editing.": "Premeu <span class=\"ephox-polish-help-kbd\">ESC</span> per ignorar les imatges locals i continuar amb l\'edici\u00F3.",
"Please wait...": "Espereu-vos...",
"Your browser security settings may be preventing images from being imported.": "\u00C9s possible que la configuraci\u00F3 de seguretat del navegador impedeixi la importaci\u00F3 d\'imatges.",
"Your browser security settings may be preventing images from being imported. <a href=\"https://support.ephox.com/entries/59328357-Safari-6-1-and-7-Flash-Sandboxing\" style=\"text-decoration: underline\">More information on paste for Safari</a>": "\u00C9s possible que la configuraci\u00F3 de seguretat del navegador impedeixi la importaci\u00F3 d\'imatges. <a href=\"https://support.ephox.com/entries/59328357-Safari-6-1-and-7-Flash-Sandboxing\" style=\"text-decoration: underline\">M\u00E9s informaci\u00F3 sobre l\'eina enganxar a Safari</a>",
"Safari does not support direct paste of images. <a href=\"https://support.ephox.com/entries/88543243-Safari-Direct-paste-of-images-does-not-work\" style=\"text-decoration: underline\">More information on image pasting for Safari</a>": "Safari no permet enganxar imatges directament. <a href=\"https://support.ephox.com/entries/88543243-Safari-Direct-paste-of-images-does-not-work\" style=\"text-decoration: underline\">M\u00E9s informaci\u00F3 sobre com enganxar imatges a Safari</a>",
"The images service was not found: (": "No s\'\'ha trobat el servei d\'\'imatges: (",
"Image failed to upload: (": "La imatge no s\'\'ha pogut carregar: (",
").": ").",
"Local image paste has been disabled. Local images have been removed from pasted content.": "L\'opci\u00F3 d\'enganxar imatges locals s\'ha desactivat. Les imatges locals s\'han eliminat del contingut enganxat."
});