# DOMPurify library

Taken from  https://api.github.com/repos/cure53/DOMPurify/tarball/2.2.2
