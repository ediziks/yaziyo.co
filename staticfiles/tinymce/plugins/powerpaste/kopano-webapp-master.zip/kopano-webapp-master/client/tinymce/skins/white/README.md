WebApp white skin
------------------

WebApp's custom white skin, to change the skin, upload
the skin.json to the [skin creator website](http://skin.tinymce.com/).

The Webapp's CSS ovewrites some of the border of the buttons, see
_tinymce.scss for more details.
